<?
	/**
	 * 25/Nov/2007 V1.0
	 * jquery 1.2.1 added
	 * minor change
	 * 
	 * 21/May/2007 V0.5
	 * inital release
	 */
?>