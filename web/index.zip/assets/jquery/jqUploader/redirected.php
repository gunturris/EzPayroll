<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN">
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>jqUploader demo - Result</title>
<link rel="stylesheet" type="text/css" media="screen" href="style.css"/>
</head>
<body>
<div id="page">
<h1>You have been redirected !</h1>
<p>(Click <a href="test.php">here</a>) to go back) </p>
<p> Your file info:</p>
<pre>
<?php
print_r($_POST);

?>
</pre>

</div>
</body>
</html>