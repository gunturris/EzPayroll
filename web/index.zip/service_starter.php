<?php
if(! defined('DEFAULT_WEB_URL')){
	die("ERROR !! : Cannot access directly!!!");
}
