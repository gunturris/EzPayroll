<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- jQuery -->
    <script src="<?php echo my_template_position(); ?>/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo my_template_position(); ?>/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo my_template_position(); ?>/js/plugins/metisMenu/metisMenu.min.js"></script>


    <title>e Penggajian - Penggajian elektronik sederhana</title>

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo my_template_position(); ?>/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="<?php echo my_template_position(); ?>/css/plugins/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Timeline CSS -->
    <link href="<?php echo my_template_position(); ?>/css/plugins/timeline.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo my_template_position(); ?>/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="<?php echo my_template_position(); ?>/css/plugins/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="<?php echo my_template_position(); ?>/font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
<?php   
if(isset($js_file))print $js_file; 
if(isset($css_file))print $css_file;
?>
<script language="Javascript">
	<?php
	//if(defined('JS_CODE'))print JS_CODE;
	if(isset($js_code))print $js_code;
	?>
	<?php
	if(isset($js_jquery_code))
	print  '$(document).ready(function() {
	'.
	$js_jquery_code
	.
	'})';
	?>
</script>
</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Sistim Pengupahan Elektronik (Ver 2.14)</a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right"> 
				<li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i>  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Ganti password</a>
                        </li>
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> Riwayat login</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="login.php?logout=<?php echo sha1(rand(0,10000));?>"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar-search">
                            <div class="input-group custom-search-form">
                                 
                            </div>
                            <!-- /input-group -->
                        </li>
                        <li>
                            <a class="active" href="index.html"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li> 
                        <li>
                            <a href="#"><i class="fa fa-table fa-fw"></i> Renumerasi<span class="fa arrow"></span></a>
							<ul class="nav nav-second-level"> 
                                <li>
                                    <a href="index.php?com=karyawan_renumerasi"><i class="fa fa-clock-o fa-fw"></i> Dasar penghitungan</a>
                                </li>
								<li>
                                    <a href="index.php?com=pay_komponen_manual"><i class="fa fa-floppy-o fa-fw"></i> Data manual</a>
                                </li>
								<li>
                                    <a href="index.php?com=pay_komponen_exception"><i class="fa fa-external-link fa-fw"></i> Data eksepsi</a>
                                </li>
							</ul>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-tasks fa-fw"></i> Proses gaji<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="#"><i class="fa fa-calendar fa-fw"></i> Reguler<span class="fa arrow"></span></a>
                                    <ul class="nav nav-third-level">
                                        <li>
                                            <a href="index.php?com=pay_periode_reguler"><i class="fa fa-check-circle fa-fw"></i> Setel periode</a>
                                        </li>
                                        <li>
                                            <a href="index.php?com=pay_proses_kalkulasi_reguler"><i class="fa fa-check-circle fa-fw"></i> Kalkulasi</a>
                                        </li>
                                        <li>
                                            <a href="#"><i class="fa fa-check-circle fa-fw"></i> Komponen</a>
                                        </li>
                                        <li>
                                            <a href="#"><i class="fa fa-check-circle fa-fw"></i> Pajak</a>
                                        </li> 
                                        <li>
                                            <a href="#"><i class="fa fa-check-circle fa-fw"></i> Tutup</a>
                                        </li> 
                                    </ul> 
                                </li>
								
								<li>
                                    <a href="#"><i class="fa fa-clipboard fa-fw"></i> Unreguler<span class="fa arrow"></span></a>
                                    <ul class="nav nav-third-level">
                                        <li>
                                            <a href="#"><i class="fa fa-check-circle fa-fw"></i> Setel parameter</a>
                                        </li>
                                        <li>
                                            <a href="#"><i class="fa fa-check-circle fa-fw"></i> Kalkulasi</a>
                                        </li>
                                        <li>
                                            <a href="#"><i class="fa fa-check-circle fa-fw"></i> Komponen</a>
                                        </li>
                                        <li>
                                            <a href="#"><i class="fa fa-check-circle fa-fw"></i> Pajak</a>
                                        </li> 
                                        <li>
                                            <a href="#"><i class="fa fa-check-circle fa-fw"></i> Tutup</a>
                                        </li> 
                                    </ul> 
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-users fa-fw"></i> Karyawan<span class="fa arrow"></span></a>
							<ul class="nav nav-second-level">
                                <li>
                                    <a href="index.php?com=karyawan"><i class="fa fa-user-md fa-fw"></i> Data karyawan</a>
                                </li>
                                <li>
                                    <a href="index.php?com=karyawan_bank"><i class="fa fa-dollar fa-fw"></i> Rekening bank</a>
                                </li>
                            </ul>
                        </li> 
                        <li>
                            <a href="#"><i class="fa fa-cogs fa-fw"></i> Konfigurasi<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level"> 
                                <li>
                                    <a href="#"><i class="fa fa-suitcase fa-fw"></i> Komponen gaji<span class="fa arrow"></span></a>
                                    <ul class="nav nav-third-level">
                                        <li>
                                            <a href="index.php?com=pay_komponen_gaji&type=pendapatan">&nbsp; <i class="fa fa-check-circle fa-fw"></i> Pendapatan</a>
                                        </li>
                                        <li>
                                            <a href="index.php?com=pay_komponen_gaji&type=subsidi">&nbsp; <i class="fa fa-check-circle fa-fw"></i> Subsidi</a>
                                        </li>
                                        <li>
                                            <a href="index.php?com=pay_komponen_gaji&type=potongan">&nbsp; <i class="fa fa-check-circle fa-fw"></i> Potongan</a>
                                        </li>
                                    </ul>
                                    <!-- /.nav-third-level --> 
                                </li>
								<li>
                                    <a href="#"><i class="fa fa-building-o fa-fw"></i> Tarif dasar<span class="fa arrow"></span></a>
                                    <ul class="nav nav-third-level">
                                        <li>
                                            <a href="index.php?com=pay_benefit_group&type=tunjangan">&nbsp; <i class="fa fa-check-circle fa-fw"></i> Tunjangan</a>
                                        </li>
                                        <li>
                                            <a href="index.php?com=pay_benefit_group&type=potongan">&nbsp; <i class="fa fa-check-circle fa-fw"></i> Potongan</a>
                                        </li>
                                        <li>
                                            <a href="index.php?com=pay_benefit_group&type=subsidi">&nbsp; <i class="fa fa-check-circle fa-fw"></i> Subsidi</a>
                                        </li> 
                                    </ul>
                                    <!-- /.nav-third-level --> 
                                </li>
								<li>
                                    <a href="#"><i class="fa fa-folder-open fa-fw"></i> Data referensi<span class="fa arrow"></span></a>
                                    <ul class="nav nav-third-level">
                                        <li>
                                            <a href="index.php?com=karyawan_status">&nbsp; <i class="fa fa-check-circle fa-fw"></i> Status karyawan</a>
                                        </li>
                                        <li>
                                            <a href="index.php?com=karyawan_gol_jab">&nbsp; <i class="fa fa-check-circle fa-fw"></i> Klasifikasi level</a>
                                        </li>
                                        <li>
                                            <a href="index.php?com=tax_ptkp_categori">&nbsp; <i class="fa fa-check-circle fa-fw"></i> Kategori PTKP</a>
                                        </li>
                                        <li>
                                            <a href="index.php?com=pay_jurnal_gaji">&nbsp; <i class="fa fa-check-circle fa-fw"></i> Jurnal gaji</a>
                                        </li>
                                    </ul>
                                    <!-- /.nav-third-level --> 
                                </li> 
                                <li>
                                    <a href="#"><i class="fa fa-users fa-fw"></i> Setup<span class="fa arrow"></span></a>
									<ul class="nav nav-third-level">
                                        <li>
                                            <a href="index.php?com=master_konfigurasi">&nbsp; <i class="fa fa-check-circle fa-fw"></i> Data wajib pajak</a>
                                        </li> 
										<li>
											<a href="index.php?com=user">&nbsp; <i class="fa fa-check-circle fa-fw"></i> Pengguna aplikasi</a>
										</li>
                                        <li>
                                            <a href="index.php?com=broadcast">&nbsp; <i class="fa fa-check-circle fa-fw"></i> Notifikasi/ Publikasi</a>
                                        </li> 
                                    </ul>
                                </li> 
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-files-o fa-fw"></i> Sample Pages<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="blank.html">Blank Page</a>
                                </li>
                                <li>
                                    <a href="login.html">Login Page</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h4 class="page-header"><?php echo $sidebar; ?></h4>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <?php echo $content; ?> 
        </div>
        <!-- /#page-wrapper -->

    </div> 
    <!-- Custom Theme JavaScript -->
    <script src="<?php echo my_template_position(); ?>/js/sb-admin-2.js"></script>

</body>

</html>
