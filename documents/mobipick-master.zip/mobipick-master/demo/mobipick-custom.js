var page = $( ":jqmData(role='page')" );

page.find( "input[type='date'].mobipick-demo-basic" ).mobipick();



